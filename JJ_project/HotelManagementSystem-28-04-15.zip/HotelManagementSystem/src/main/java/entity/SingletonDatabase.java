package entity;

import control.roomDecorator.*;
import control.reservationState.Reservation;
import control.reservationState.ReservationStatus;
import control.userFactory.Guest;
import control.userFactory.Manager;
import control.userFactory.Receptionist;
import control.userFactory.User;

import java.util.ArrayList;

/**
 * Created by Ross on 24/03/2015.
 */
public class SingletonDatabase {

    private static SingletonDatabase instance;

    private static ArrayList<I_Room> i_rooms = new ArrayList<I_Room>(); // decorator pattern
    private static ArrayList<User> registeredUsers = new ArrayList<User>();

    // declared private constructor only initialized once
    private SingletonDatabase()
    {
        registeredUsers.add(new Manager("jack", "123", "Manager"));
        registeredUsers.add(new Receptionist("mike", "456", "Receptionist"));
        registeredUsers.add(new Guest("ross", "789", "Guest", "123456","limerick", "(087)789654"));

        i_rooms.add(new RoomBreakfast(new RoomKingSize(new Room("KingSize special", "Special offer Kingsize bed with breakfast!", 11, 40, new Reservation()))));
        i_rooms.add(new RoomBreakfast(new RoomMinibar(new RoomOnSuite(new RoomOnSuite(new RoomKingSize(new Room("All included", "All extras included", 22, 70, new Reservation())))))));
        i_rooms.add(new RoomBreakfast(new RoomOnSuite(new RoomKingSize(new Room("Regular Kingsize", "Kingsize with on-suite", 33, 35, new Reservation())))));
        i_rooms.add(new RoomBreakfast(new RoomWifi(new Room("Single Special", "Single room with wifi and breakfast", 44, 25, new Reservation()))));


        for(int i = 0; i < i_rooms.size(); i++) {
            i_rooms.get(i).getReservation().setStatus(ReservationStatus.NEW);
        }

    }

    // access to the static database
    public static SingletonDatabase getInstance()
    {
        if(instance == null)
        {
            instance = new SingletonDatabase();
        }
        return instance;
    }

    public User searchUsers(String username)
    {
        for(int i = 0; i < registeredUsers.size(); i++)
        {
            if(registeredUsers.get(i).getUsername().equals(username))
            {
                return registeredUsers.get(i);
            }
        }
        return null;
    }

    public I_Room searchI_Rooms(int roomNumber)
    {
        for(int i = 0; i < i_rooms.size(); i++)
        {
            if(i_rooms.get(i).getNumber() == (roomNumber))
            {
                return i_rooms.get(i);
            }
        }
        return null;
    }

    public ArrayList<I_Room> getI_Rooms() {
        return i_rooms;
    }

    public ArrayList<User> getRegisteredUsers() {
        return registeredUsers;
    }

    public void setRegisteredUsers(ArrayList<User> registeredUsers) {
        this.registeredUsers = registeredUsers;
    }
}
