package boundary;

import control.*;
import control.Room_Control;
import control.NewUser_Control;

/**
 * Created by Ross on 23/04/2015.
 */
public class Control_UI {

    private static Login_UI login_ui;
    private static Guest_UI guest_ui;
    private static NewUser_UI newUser_ui;
    private static Receptionist_UI receptionist_ui;
    private static Reservation_UI reservation_ui;
    private static Manager_UI manger_ui;

    public static void init()
    {
        login_ui = new Login_UI();
        guest_ui = new Guest_UI();
        newUser_ui = new NewUser_UI();
        receptionist_ui = new Receptionist_UI();
        reservation_ui = new Reservation_UI();
        manger_ui = new Manager_UI();
    }

    public static Login_UI getLoginUI()
    {
        return login_ui;
    }

    public static Guest_UI getGuestUI()
    {
        return guest_ui;
    }

    public static NewUser_UI getNewUserUI()
    {
        return newUser_ui;
    }

    public static Receptionist_UI getReceptionistUI()
    {
        return receptionist_ui;
    }

    public static Reservation_UI getReservationUI()
    {
        return reservation_ui;
    }

    public static Manager_UI getManagerUI() {
        return manger_ui;
    }

}

