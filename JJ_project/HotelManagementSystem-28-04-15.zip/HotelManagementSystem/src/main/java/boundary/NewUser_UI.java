package boundary;
/**
 * Created by Ross on 14/03/2015.
 */
import control.Control_Manager;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class NewUser_UI extends JFrame implements ActionListener
{
    private JTextField addressText;
    private JTextField telephoneText;
    private JTextField passportText;
    private JTextField userText;
    private JPasswordField passwordField;
    private JButton registerButton;
    private JFrame frame;
    private JButton backButton;
    private JCheckBox cbxReceptionist;
    private JCheckBox cbxGuest;
    private JCheckBox cbxManager;

    public NewUser_UI()
    {

    }

    public void displayGUI() {
        
        frame = new JFrame("Register here");
        frame.setSize(350, 250);
        frame.setLocation(500, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();

        frame.add(panel);

        JLabel userLabel = new JLabel("User Name");
        userLabel.setBounds(10, 10, 80, 25);
        panel.add(userLabel);

        userText = new JTextField(20);
        userText.setBounds(100, 10, 160, 25);
        panel.add(userText);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(10, 40, 80, 25);
        panel.add(passwordLabel);

        passwordField = new JPasswordField(20);
        passwordField.setBounds(100, 40, 160, 25);
        panel.add(passwordField);

        JLabel addressLabel = new JLabel("Address");
        userLabel.setBounds(10, 70, 80, 25);
        panel.add(addressLabel);

        addressText = new JTextField(20);
        addressText.setBounds(100, 70, 160, 25);
        panel.add(addressText);

        JLabel telephoneLabel = new JLabel("Telephone");
        telephoneLabel.setBounds(10, 100, 80, 25);
        panel.add(telephoneLabel);

        telephoneText = new JTextField(20);
        telephoneText.setBounds(100, 100, 160, 25);
        panel.add(telephoneText);

        JLabel passportLabel = new JLabel("Passport Number");
        passportLabel.setBounds(10, 130, 80, 25);
        panel.add(passportLabel);

        passportText = new JTextField(20);
        passportText.setBounds(100, 130, 160, 25);
        panel.add(passportText);

        registerButton = new JButton("register");
        registerButton.setBounds(10, 160, 80, 25);
        panel.add(registerButton);

        JLabel m = new JLabel("Manager");
        panel.add(m);
        cbxManager = new JCheckBox();
        panel.add(cbxManager);

        JLabel g = new JLabel("Guest");
        panel.add(g);
        cbxGuest = new JCheckBox();
        panel.add(cbxGuest);

        JLabel r = new JLabel("Receptionist");
        panel.add(r);
        cbxReceptionist = new JCheckBox();
        panel.add(cbxReceptionist);

        backButton = new JButton("back");
        backButton.setBounds(10, 160, 160, 25);
        panel.add(backButton);

        backButton.addActionListener(this);
        registerButton.addActionListener(this);

        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == registerButton)
        {
            String type = "";
            if(cbxGuest.isSelected())
            {
                type = "Guest";
            }
            else if(cbxManager.isSelected())
            {
                type = "Manager";
            }
            else if(cbxReceptionist.isSelected())
            {
                type = "Receptionist";
            }
            if(cbxGuest.isSelected() || cbxManager.isSelected() || cbxReceptionist.isSelected()) {
                String address = addressText.getText();
                String tel = telephoneText.getText();
                String password = passwordField.getText();
                String username = userText.getText();
                String passport = passportText.getText();
                if ((!address.equalsIgnoreCase("") && (!tel.equalsIgnoreCase("")) && (!passport.equalsIgnoreCase("")) && (!username.equalsIgnoreCase("")) && (!password.equalsIgnoreCase("")))) {
                    Control_Manager.getNewUserControl().createRegisteredUser(username, password, address, passport, tel, type);
                    frame.dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "You must enter all fields..", "Try Again", JOptionPane.ERROR_MESSAGE);
                }
            }
            else JOptionPane.showMessageDialog(null, "Error: You must select a type!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        else if(e.getSource() == backButton)
        {
            Control_Manager.getLoginControl().displayNewUserUI();
            frame.dispose();

        }

    }
}
    