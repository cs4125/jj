package boundary;

/**
 * Created by Ross on 16/03/2015.
 */
import control.Control_Manager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class Receptionist_UI extends JFrame implements ActionListener
{
    private JButton logOutButton;
    private JFrame frame;
    private JButton browseButton;
    private JButton reservationButton;
    private JPanel panel;
    private JButton browseOccupiedButton;
    private JButton cancelReservationButton;
    private JButton viewCancelledButton;
    private JTextField txbRoom;
    private JButton browseAvailableButton;
    private JButton makeCancelledAvailableButton;

    public Receptionist_UI()
    {

    }

    public void displayGUI(String username)
    {
        frame = new JFrame("Receptionist Menu");
        frame.setLocation(500, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel();
        frame.add(panel);

        panel.setLayout(new GridLayout(4, 4));

        JLabel userLabel = new JLabel("Welcome to Receptionist menu : " + username);
        userLabel.setBounds(10, 10, 80, 25);
        panel.add(userLabel);

        browseButton = new JButton("Browse Rooms");
        panel.add(browseButton);

        browseOccupiedButton = new JButton("Browse Occupied Rooms");
        panel.add(browseOccupiedButton);

        reservationButton = new JButton("Make Reservation");
        panel.add(reservationButton);

        browseAvailableButton = new JButton("Browse Available Rooms");
        panel.add(browseAvailableButton);

        txbRoom = new JTextField(6);
        panel.add(txbRoom);

        cancelReservationButton = new JButton("Cancel Reservation");
        panel.add(cancelReservationButton);

        viewCancelledButton = new JButton("View Cancelled Reservations");
        panel.add(viewCancelledButton);

        makeCancelledAvailableButton = new JButton("Refresh room");
        panel.add(makeCancelledAvailableButton);

        //create new button
        logOutButton = new JButton("log out");
        panel.add(logOutButton);

        logOutButton.addActionListener(this);
        browseButton.addActionListener(this);
        reservationButton.addActionListener(this);
        browseOccupiedButton.addActionListener(this);
        viewCancelledButton.addActionListener(this);
        browseAvailableButton.addActionListener(this);
        cancelReservationButton.addActionListener(this);
        makeCancelledAvailableButton.addActionListener(this);

        frame.pack();

        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == logOutButton)
        {
            Control_Manager.getLoginControl().displayNewUserUI();
            frame.dispose();
        }

        else if(e.getSource() == browseButton)
        {
            JOptionPane.showMessageDialog(null, Control_Manager.getRoomControl().displayAllRooms(), "Displaying all rooms", JOptionPane.INFORMATION_MESSAGE);
        }

        else if(e.getSource() == browseAvailableButton)
        {
            JOptionPane.showMessageDialog(null, Control_Manager.getRoomControl().displayAvailableRooms(), "Displaying available rooms", JOptionPane.INFORMATION_MESSAGE);
        }

        else if(e.getSource() == browseOccupiedButton)
        {
            JOptionPane.showMessageDialog(null, Control_Manager.getRoomControl().displayOccupiedRooms(), "Displaying occupied rooms", JOptionPane.INFORMATION_MESSAGE);
        }

        else if(e.getSource() == viewCancelledButton)
        {
            JOptionPane.showMessageDialog(null, Control_Manager.getRoomControl().displayCancelledRooms(), "Displaying cancelled rooms", JOptionPane.INFORMATION_MESSAGE);
        }

        else if(e.getSource() == cancelReservationButton)
        {
            Control_Manager.getReservationControl().cancelReservation(Integer.valueOf(txbRoom.getText()));
        }

        else if(e.getSource() == reservationButton)
        {
            Control_Manager.getReservationControl().reserveRoom(Integer.valueOf(txbRoom.getText()));
        }

        else if(e.getSource() == makeCancelledAvailableButton)
        {
            Control_Manager.getReservationControl().refreshReservation(Integer.valueOf(txbRoom.getText()));
        }
    }
}
