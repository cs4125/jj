package boundary;

/**
 * Created by Ross on 21/03/2015.
 */
import control.Control_Manager;
import control.Login_Control;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Reservation_UI extends JFrame implements ActionListener {
    private JButton backButton;
    private JFrame frame;
    private JButton browseButton;
    private JButton reservationButton;
    private static JTextField txbRoom;
    private JButton cancelReservationButton;

    public Reservation_UI()
    {

    }

    public void displayGUI()
    {
        frame = new JFrame("Reservation Menu");
        frame.setSize(300, 250);
        frame.setLocation(500, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        frame.add(panel);


        JLabel userLabel = new JLabel("Welcome to Reservation Menu");
        userLabel.setBounds(10, 10, 80, 25);
        panel.add(userLabel);

        browseButton = new JButton("Browse Available Rooms");
        browseButton.setBounds(10, 80, 160, 25);
        panel.add(browseButton);

        reservationButton = new JButton("Reserve Room");
        reservationButton.setBounds(10, 100, 160, 25);
        panel.add(reservationButton);

        txbRoom = new JTextField(6);
        txbRoom.setBounds(100, 10, 160, 25);
        panel.add(txbRoom);

        cancelReservationButton = new JButton("Cancel Reservation");
        cancelReservationButton.setBounds(10, 120, 160, 25);
        panel.add(cancelReservationButton);

        backButton = new JButton("back");
        backButton.setBounds(10, 140, 160, 25);
        panel.add(backButton);

        backButton.addActionListener(this);
        browseButton.addActionListener(this);
        reservationButton.addActionListener(this);
        cancelReservationButton.addActionListener(this);

        frame.setVisible(true);
    }
   
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == backButton)
        {
            Control_UI.getGuestUI().displayGUI(Login_Control.getUser().getUsername());
            frame.dispose();
        }

        else if(e.getSource() == browseButton)
        {
            JOptionPane.showMessageDialog(null, Control_Manager.getRoomControl().displayAvailableRooms(), "Displaying available rooms", JOptionPane.INFORMATION_MESSAGE);
        }

        else if(e.getSource() == cancelReservationButton)
        {
            Control_Manager.getReservationControl().cancelReservation(Integer.valueOf(txbRoom.getText()));
        }

        else if(e.getSource() == reservationButton)
        {
            Control_Manager.getReservationControl().reserveRoom(Integer.valueOf(txbRoom.getText()));
        }
    }
}