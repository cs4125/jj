package control;

import boundary.Control_UI;
import control.userFactory.Guest;

public class Guest_Control {


    public Guest_Control()
    {

    }

    public void displayGuestUI(Guest guest)
    {
        Control_UI.getGuestUI().displayGUI(guest.getUsername());
    }


}
