package control;

import control.*;
import control.Room_Control;
import control.NewUser_Control;

/**
 * Created by Ross on 23/04/2015.
 */
public class Control_Manager {

    private static Login_Control login_control;
    private static Guest_Control guest_control;
    private static NewUser_Control newUser_control;
    private static Receptionist_Control receptionist_control;
    private static Reservation_Control reservation_control;
    private static Manger_Control mangerControl;
    private static Room_Control room_control;

    public static void init()
    {
        login_control = new Login_Control();
        guest_control = new Guest_Control();
        newUser_control = new NewUser_Control();
        receptionist_control = new Receptionist_Control();
        reservation_control = new Reservation_Control();
        mangerControl = new Manger_Control();
        room_control = new Room_Control();
    }

    public static Login_Control getLoginControl()
    {
        return login_control;
    }

    public static Guest_Control getGuestControl()
    {
        return guest_control;
    }

    public static NewUser_Control getNewUserControl()
    {
        return newUser_control;
    }

    public static Receptionist_Control getReceptionistControl()
    {
        return receptionist_control;
    }

    public static Reservation_Control getReservationControl()
    {
        return reservation_control;
    }

    public static Manger_Control getManagerControl() {
        return mangerControl;
    }
    public static Room_Control getRoomControl()
    {
        return room_control;
    }

}
