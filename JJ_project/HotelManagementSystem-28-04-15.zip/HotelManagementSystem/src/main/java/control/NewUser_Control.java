package control;
/**
 * Created by Ross on 29/03/2015.
 */
import boundary.Control_UI;
import control.userFactory.*;

import javax.swing.*;

public class NewUser_Control {

    public NewUser_Control()
    {

    }

    public void displayNewUserUI()
    {
        Control_UI.getNewUserUI().displayGUI();
    }

    public void createRegisteredUser(String username, String password, String address, String passport, String telephone, String type)
    {
        UserFactory user = new UserFactory();
        User newUser = user.createUser(username, password, type);
        // cast to Guest
        if(newUser instanceof Guest) {
            Guest newGuest = (Guest) newUser;
            // set details
            newGuest.setAddress(address);
            newGuest.setPassportNumber(passport);
            newGuest.setTelephone(telephone);
            // add new Guest
            addNewUser(newGuest);
        }
        else if(newUser instanceof Receptionist)
        {
            Receptionist newReceptionist = (Receptionist) newUser;
            addNewUser(newReceptionist);
        }
        else if(newUser instanceof Manager)
        {
            Manager manager = (Manager) newUser;
            addNewUser(manager);
        }
        // go through Control_Login to validate new User is in the System
        Control_Manager.getLoginControl().login(newUser.getUsername(),newUser.getPassword());
    }

    private void addNewUser(User user)
    {
        // static call to database in Control_Login
        Login_Control.singletonDatabase.getRegisteredUsers().add(user);
        JOptionPane.showMessageDialog(null, "Created new " + user.getUsername(), "New User", JOptionPane.INFORMATION_MESSAGE);
    }
}

