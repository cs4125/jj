package control;

import control.roomDecorator.I_Room;
import entity.SingletonDatabase;
import control.reservationState.ReservationStatus;

import javax.swing.*;
import java.util.GregorianCalendar;

public class Reservation_Control {

    I_Room i_room;

    public Reservation_Control()
    {

    }

    public void reserveRoom(int roomNumber)
    {
        i_room = SingletonDatabase.getInstance().searchI_Rooms(roomNumber);
        if(i_room != null) {
            if (i_room.getReservation().getStatus() == ReservationStatus.NEW) {
                int i = (int) Math.random() * 100000 + 1;
                JOptionPane.showMessageDialog(null, "Reserving room: " + i_room.getNumber(), "Reservation Accepted", JOptionPane.INFORMATION_MESSAGE);
                i_room.getReservation().accept();
                i_room.getReservation().setPrice(i_room.getCost());
                i_room.getReservation().setName(Login_Control.getUser().getUsername());
                i_room.getReservation().setId(i);
                i_room.getReservation().setDate(new GregorianCalendar().getTime());

                JOptionPane.showMessageDialog(null, "Reservation ID: " + i_room.getReservation().getId() + "\nReservation Date: " + i_room.getReservation().getDate() + "\nName: " + i_room.getReservation().getName() + "\nRoom & Cost: " + i_room.getNumber() + " " + i_room.getReservation().getPrice(), "Reservation Details", JOptionPane.INFORMATION_MESSAGE);
                // make payment

                i_room.getReservation().accept();
            }
        }
        JOptionPane.showMessageDialog(null, "Error room not found!", "Error", JOptionPane.ERROR_MESSAGE);
   }

    public void cancelReservation(int roomNumber)
    {
        i_room = SingletonDatabase.getInstance().searchI_Rooms(roomNumber);
        if(i_room != null) {
            JOptionPane.showMessageDialog(null, "Cancelling Reservation on room: " + i_room.getNumber(), "Reservation Cancelled", JOptionPane.INFORMATION_MESSAGE);
            i_room.getReservation().cancel();
        }else
            JOptionPane.showMessageDialog(null, "Error room not found!", "Error", JOptionPane.ERROR_MESSAGE);
    }

    public void refreshReservation(int roomNumber)
    {
        i_room = SingletonDatabase.getInstance().searchI_Rooms(roomNumber);
        if(i_room != null) {
            JOptionPane.showMessageDialog(null, "Renewing Reservation on room: " + i_room.getNumber(), "Reservation status changed to available", JOptionPane.INFORMATION_MESSAGE);
            i_room.getReservation().setStatus(ReservationStatus.NEW);
        }else
        JOptionPane.showMessageDialog(null, "Error room not found!", "Error", JOptionPane.ERROR_MESSAGE);

    }

}
