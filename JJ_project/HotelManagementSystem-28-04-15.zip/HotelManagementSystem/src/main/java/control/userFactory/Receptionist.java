package control.userFactory;

/**
 * Created by Ross on 24/03/2015.
 */
public class Receptionist extends User
{

    public Receptionist(String username, String password, String userType) {
        super(username, password, userType);
    }
}
