package control.userFactory;

/**
 * Created by Ross on 24/03/2015.
 */
public class Manager extends User
{

    public Manager(String username, String password, String userType) {
        super(username, password, userType);
    }
}
