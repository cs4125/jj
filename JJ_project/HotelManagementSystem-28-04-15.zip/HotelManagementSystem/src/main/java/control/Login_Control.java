package control;

import boundary.Control_UI;
import boundary.Login_UI;
import entity.*;
import control.userFactory.Guest;
import control.userFactory.Manager;
import control.userFactory.Receptionist;
import control.userFactory.User;

public class Login_Control {

    // Database static object so it stays persistent throughout the program lifespan
    public static SingletonDatabase singletonDatabase = SingletonDatabase.getInstance();
    private static User user;

    // constructor for Login Control
    public Login_Control()
    {

    }

    public void displayNewUserUI()
    {
        Control_UI.getLoginUI().displayGUI();
    }

    // login method
    public void login(String username, String password)
    {

        // create user and search in database
        user = singletonDatabase.searchUsers(username);

        if(user != null) {

            // get the password of the found user
            String dbPassword = user.getPassword();

            // successful recovery
            if (dbPassword != null && dbPassword.equals(password)) {

                    if (user instanceof Guest) {
                        Control_Manager.getGuestControl().displayGuestUI((Guest)user);

                    } else if (user instanceof Receptionist) {
                        Control_Manager.getReceptionistControl().displayReceptionUI((Receptionist)user);

                    } else if (user instanceof Manager) {
                        Control_Manager.getManagerControl().displayManagerUI((Manager)user);
                    }
                }
            }
        // user does not exist
        else
        {
            Control_UI.getLoginUI().loginErrorMessage(username, password);
            Control_UI.getLoginUI().displayGUI();
        }
    }

    public static User getUser()
    {
        return user;
    }

}
