package control;

import boundary.Control_UI;
import boundary.Login_UI;

import javax.swing.*;

/**
 * Created by Ross on 04/04/2015.
 */
public class Main
{
    // main method
    public static void main(String[] args) {

        JOptionPane.showMessageDialog(null, "jack 123 = Manager"
                + "\nmike 456 = Receptionist"
                + "\nross 789 = Guest", null, 1);

        Control_Manager.init();
        Control_UI.init();

        Control_UI.getLoginUI().displayGUI();
    }
}
