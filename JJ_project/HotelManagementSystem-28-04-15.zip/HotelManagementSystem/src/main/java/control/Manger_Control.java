package control;

// Manager has unique methods
// Manager has methods inherited from Receptionist
// Receptionist has methods inherited from Guest

import boundary.Control_UI;
import boundary.Manager_UI;
import control.userFactory.Manager;
import entity.SingletonDatabase;


public class Manger_Control {

    private Manager_UI showManagerMenu;
    
    // constructor for boundary
    public Manger_Control() {
    }

    public void displayManagerUI(Manager manager) {
        Control_UI.getManagerUI().displayGUI();
    }
}
