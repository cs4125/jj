package control;

import control.roomDecorator.I_Room;
import control.roomDecorator.Room;
import entity.SingletonDatabase;
import control.reservationState.ReservationStatus;

import java.util.ArrayList;

public class Room_Control {

    ArrayList<I_Room> i_rooms = SingletonDatabase.getInstance().getI_Rooms();

    public Room_Control()
    {

    }

    public String displayAllRooms()
    {
        String roomDetails = "List of All Rooms: \n";
        for(I_Room room : i_rooms )
        {
            roomDetails += "Room Number: " + room.getNumber() + " Room Type: " + room.getDescription() + " Cost: " + room.getCost() + "\n";
        }
        return roomDetails;
    }

    public String displayOccupiedRooms()
    {
        String roomDetails = "List of Occupied Rooms: \n";
        for(I_Room room : i_rooms)
        {
            if(room.getReservation().getStatus() == ReservationStatus.ACCEPTED)
            {
                roomDetails += "Room Number: " + room.getNumber() + " Room Type: " + room.getDescription() + " Cost: " + room.getCost() + "\n";
            }
        }
        return roomDetails;
    }

    public String displayAvailableRooms()
    {
        String roomDetails = "List of Available Rooms: \n";
        for(I_Room room : i_rooms)
        {
            if(room.getReservation().getStatus() == ReservationStatus.NEW)
            {
                roomDetails += "Room Number: " + room.getNumber() + " Room Type: " + room.getDescription() + " Cost: " + room.getCost() + "\n";
            }
        }
        return roomDetails;
    }


    public String displayCancelledRooms()
    {
        String roomDetails = "List of Cancelled Rooms: \n";
        for(I_Room room : i_rooms)
        {
            if(room.getReservation().getStatus() == ReservationStatus.CANCELLED)
            {
                roomDetails += "Room Number: " + room.getNumber() + " Room Type: " + room.getDescription() + " Cost: " + room.getCost() + "\n";
            }
        }
        return roomDetails;
    }
}
