package control;


import boundary.Control_UI;
import control.userFactory.Receptionist;

public class Receptionist_Control {

    public Receptionist_Control() {

    }

    public void displayReceptionUI(Receptionist receptionist)
    {
        Control_UI.getReceptionistUI().displayGUI(receptionist.getUsername());
    }

}
