package control.roomDecorator;

import control.reservationState.Reservation;

/**
 * Created by Ross on 05/04/2015.
 */
public interface I_Room
{
    public String getDescription();
    public double getCost();
    public int getNumber();
    public Reservation getReservation();
}
