package control.roomDecorator;

import control.reservationState.Reservation;

/**
 * Created by Ross on 05/04/2015.
 */
public class RoomBreakfast extends RoomDecorator
{
    // must explicitly call super
    public RoomBreakfast(I_Room i_room) {
        super(i_room);
    }

    public String getDescription()
    {
        return tempI_room.getDescription() + ", Including Breakfast.";
    }

    public double getCost()
    {
        return tempI_room.getCost() + 15.00;
    }

    @Override
    public int getNumber() {
        return tempI_room.getNumber();
    }

    @Override
    public Reservation getReservation() {
        return tempI_room.getReservation();
    }
}
