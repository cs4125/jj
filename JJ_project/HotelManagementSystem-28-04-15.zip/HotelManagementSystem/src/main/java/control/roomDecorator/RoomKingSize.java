package control.roomDecorator;

import control.reservationState.Reservation;

/**
 * Created by Ross on 04/04/2015.
 */
public class RoomKingSize extends RoomDecorator
{
    // must explicitly call super
    public RoomKingSize(I_Room i_room) {
        super(i_room);
    }

    @Override
    public String getDescription()
    {
        return tempI_room.getDescription() + ", King Size Bed.";
    }

    @Override
    public double getCost()
    {
        return tempI_room.getCost() + 20.00;
    }

    @Override
    public int getNumber() {
        return tempI_room.getNumber();
    }

    @Override
    public Reservation getReservation() {
        return tempI_room.getReservation();
    }
}
